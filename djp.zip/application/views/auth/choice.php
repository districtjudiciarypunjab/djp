<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<h1>Your choice</h1>

<p><a href="<?php echo site_url('/'); ?>">Home</a></p>

<p><a href="<?php echo site_url('admin'); ?>">Admin</a></p>

<p><a href="<?php echo site_url('auth/logout'); ?>">Logout</a></p>

