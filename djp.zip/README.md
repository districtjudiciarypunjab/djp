# District Judiciary Punjab

## Demo

Coming soon

### Login
 * as admin
 * Email : `admin@admin.com`
 * Password : `password`
 
 * District Admin
 * email : `fsd@admin.com`
 * password : `password`

## Browser Compatibility
Support for most major browsers including Chrome, Firefox, IE9+, Opera and Safari.

## Languages
  * English
